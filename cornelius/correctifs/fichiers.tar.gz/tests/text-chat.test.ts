import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import test, { type TestContext } from 'node:test';
import type { ToolResult } from '../shared/addons.js';
import { createApp } from '../server/app.js';
import {
  TextChat,
  TextChatError,
  type TextModel,
  type TextModelResponse,
} from '../server/text-chat.js';

const succeeded = (summary: string): ToolResult => ({
  schemaVersion: 1,
  status: 'succeeded',
  result: {},
  snapshotId: 's1',
  actionRunId: null,
  summary,
  error: null,
});
const card = {
  schemaVersion: 1,
  cardType: 'module',
  addonId: 'foyer',
  instanceRef: 'repas',
  title: 'Foyer · aujourd’hui',
  primaryValue: 'Ce soir : Curry de poulet',
  subtitle: null,
  description: null,
  items: [],
  sources: ['foyer'],
  snapshotId: 's1',
  stale: false,
} as const;
const call = (id: string, name: string, args: unknown = { instanceRef: null }) => ({
  type: 'function_call',
  call_id: id,
  name,
  arguments: JSON.stringify(args),
});
const answer = (text: string): TextModelResponse => ({
  status: 'completed',
  output: [{ type: 'message', content: [{ type: 'output_text', text }] }],
  output_text: text,
});
const tools = (...items: unknown[]): TextModelResponse => ({
  status: 'completed',
  output: items,
  output_text: '',
});

function harness(options: {
  blocked?: boolean;
  key?: boolean;
  script: (TextModelResponse | Error)[];
}) {
  const seen = {
    requests: [] as { input: unknown[]; tools: unknown[]; instructions: string }[],
    toolsProfile: undefined as string | null | undefined,
    haRecognized: [] as (boolean | undefined)[],
    invoked: [] as { name: string; profileId: string | null }[],
    logs: [] as unknown[],
  };
  const script = [...options.script];
  const model: TextModel = async (request) => {
    seen.requests.push(structuredClone(request));
    const next = script.shift();
    if (!next) throw new Error('script épuisé');
    if (next instanceof Error) throw next;
    return next;
  };
  const chat = new TextChat({
    model: () => (options.key === false ? null : model),
    blocked: () => options.blocked === true,
    webSearch: () => true,
    addons: {
      tools: (profileId) => {
        seen.toolsProfile = profileId;
        return [
          { name: 'foyer__read', description: 'Repas du foyer', parameters: { type: 'object' } },
        ];
      },
      parseTool: (name) =>
        name.startsWith('foyer__') ? { addonId: 'foyer', toolName: 'read' } : null,
      invoke: async (name, profileId) => {
        seen.invoked.push({ name, profileId });
        return {
          outcome: { ok: true, card } as never,
          tool: succeeded('Ce soir : Curry de poulet.'),
        };
      },
    },
    homeAssistant: {
      tools: (recognized) => {
        seen.haRecognized.push(recognized);
        return [
          {
            name: 'home_assistant__control',
            description: 'Lumières',
            parameters: { type: 'object' },
          },
        ];
      },
      handles: (name): name is 'home_assistant__control' | 'home_assistant__read' =>
        name.startsWith('home_assistant__'),
      run: async (_args, _signal, _name, recognized) => {
        seen.haRecognized.push(recognized);
        return succeeded('Lumière du salon : commande acceptée (accepted), état non confirmé.');
      },
    },
    householdStyle: () => 'Tutoiement.',
    timeZone: 'Europe/Paris',
    logs: { write: (...args: unknown[]) => void seen.logs.push(args) } as never,
    now: () => Date.parse('2026-10-21T16:00:00Z'),
  });
  return { chat, seen };
}
const signal = () => new AbortController().signal;

test('répond au nom du foyer, avec les outils des modules, de la maison et du web', async () => {
  const { chat, seen } = harness({
    script: [tools(call('c1', 'foyer__read')), answer('Ce soir, curry de poulet.')],
  });
  const reply = await chat.reply([{ role: 'user', text: 'On mange quoi ce soir ?' }], signal());
  assert.equal(reply.status, 'succeeded');
  assert.equal(reply.text, 'Ce soir, curry de poulet.');
  assert.equal(reply.cards.length, 1);
  assert.deepEqual(
    reply.actions.map((a) => a.tool),
    ['foyer__read'],
  );
  // Le foyer, jamais une personne : sources du foyer, maison sans personne reconnue.
  assert.equal(seen.toolsProfile, null);
  assert.deepEqual(seen.invoked, [{ name: 'foyer__read', profileId: null }]);
  assert.ok(seen.haRecognized.every((recognized) => recognized === false));
  const names = (seen.requests[0]!.tools as { type: string; name?: string }[]).map(
    (t) => t.name ?? t.type,
  );
  assert.deepEqual(names, ['foyer__read', 'home_assistant__control', 'web_search']);
  assert.match(seen.requests[0]!.instructions, /Tutoiement\./);
  assert.match(seen.requests[0]!.instructions, /mercredi 21 octobre 2026/);
  // Le résultat de l’outil revient au modèle avec le même identifiant d’appel.
  const outputs = seen.requests[1]!.input.filter(
    (item) => (item as { type?: string }).type === 'function_call_output',
  );
  assert.equal((outputs[0] as { call_id: string }).call_id, 'c1');
});

test('outils personnels (souvenirs, agent) : indisponibles par écrit, jamais exécutés', async () => {
  const { chat, seen } = harness({
    script: [
      tools(call('c1', 'memory__recall'), call('c2', 'agents__start')),
      answer('Je ne peux pas par écrit.'),
    ],
  });
  const reply = await chat.reply([{ role: 'user', text: 'Rappelle-moi mes souvenirs' }], signal());
  assert.equal(reply.status, 'succeeded');
  assert.deepEqual(
    reply.actions.map((a) => [a.tool, a.status]),
    [
      ['memory__recall', 'failed'],
      ['agents__start', 'failed'],
    ],
  );
  assert.equal(seen.invoked.length, 0);
});

test('mode privé : refus explicite, aucun appel à OpenAI', async () => {
  const { chat, seen } = harness({ blocked: true, script: [answer('jamais')] });
  await assert.rejects(
    chat.reply([{ role: 'user', text: 'Bonjour' }], signal()),
    (error) => error instanceof TextChatError && error.status === 409,
  );
  assert.equal(seen.requests.length, 0);
  assert.deepEqual(chat.status(), { ready: false, reason: 'blocked' });
});

test('clé absente : service indisponible, dit comme tel', async () => {
  const { chat } = harness({ key: false, script: [] });
  await assert.rejects(
    chat.reply([{ role: 'user', text: 'Bonjour' }], signal()),
    (error) => error instanceof TextChatError && error.status === 503,
  );
  assert.deepEqual(chat.status(), { ready: false, reason: 'no_key' });
});

test('panne après une commande : échec dit, commande listée, jamais « c’est fait »', async () => {
  const { chat } = harness({
    script: [
      tools(call('c1', 'home_assistant__control', { entity: 'light.salon', action: 'turn_on' })),
      new Error('réseau coupé'),
    ],
  });
  const reply = await chat.reply([{ role: 'user', text: 'Allume le salon' }], signal());
  assert.equal(reply.status, 'failed');
  assert.match(reply.text, /n’a pas pu terminer/);
  assert.doesNotMatch(reply.text, /c’est fait|allumée/i);
  assert.equal(reply.actions[0]?.tool, 'home_assistant__control');
  assert.match(reply.actions[0]?.summary ?? '', /non confirmé/);
});

test('panne sans rien lancer : « rien n’a été lancé »', async () => {
  const { chat } = harness({ script: [new Error('OpenAI indisponible')] });
  const reply = await chat.reply([{ role: 'user', text: 'Bonjour' }], signal());
  assert.equal(reply.status, 'failed');
  assert.match(reply.text, /Rien n’a été lancé/);
  assert.equal(reply.actions.length, 0);
});

test('boucle d’outils sans fin : arrêtée, douze outils au plus', async () => {
  const many = () =>
    tools(...Array.from({ length: 5 }, (_, i) => call(`c${Math.random()}${i}`, 'foyer__read')));
  const { chat, seen } = harness({ script: Array.from({ length: 6 }, many) });
  const reply = await chat.reply([{ role: 'user', text: 'Encore' }], signal());
  assert.equal(reply.status, 'failed');
  assert.ok(seen.invoked.length <= 12, String(seen.invoked.length));
});

test('réponse vide : échec, jamais un silence présenté comme une réponse', async () => {
  const { chat } = harness({ script: [answer('   ')] });
  assert.equal((await chat.reply([{ role: 'user', text: 'Bonjour' }], signal())).status, 'failed');
});

test('le texte échangé n’est jamais écrit dans le journal', async () => {
  const { chat, seen } = harness({ script: [answer('Réponse confidentielle du foyer.')] });
  await chat.reply([{ role: 'user', text: 'Question confidentielle du foyer' }], signal());
  assert.ok(seen.logs.length >= 1);
  assert.doesNotMatch(JSON.stringify(seen.logs), /confidentielle/);
});

async function app(
  t: TestContext,
  model: TextModel,
  openaiKey: string | null = 'sk-test-' + 'x'.repeat(24),
) {
  const imageRoot = mkdtempSync(join(tmpdir(), 'cornelius-text-images-'));
  const services = await createApp(
    {
      databasePath: ':memory:',
      perceptionToken: 'p'.repeat(40),
      imageGenerationToken: 'i'.repeat(40),
      adminPassword: 'mot-de-passe-texte',
      origins: ['http://localhost'],
      secureCookies: false,
      lan: true,
      httpsPort: 3443,
      openaiKey: openaiKey ?? undefined,
    },
    { timers: false, imageGenerationRoot: imageRoot, textModel: () => model },
  );
  await services.app.ready();
  t.after(async () => {
    await services.app.close();
    rmSync(imageRoot, { recursive: true, force: true });
  });
  return services.app;
}
const local = { host: 'localhost', origin: 'http://localhost' };
const body = (text: string) => ({ messages: [{ role: 'user', text }] });

test('API : appareil non autorisé refusé, message invalide refusé, réponse servie', async (t) => {
  const server = await app(t, async () => answer('Bonjour !'));
  const lan = await server.inject({
    method: 'POST',
    url: '/api/text',
    remoteAddress: '192.168.1.30',
    headers: { host: '192.168.1.20:3443', origin: 'https://192.168.1.20:3443' },
    payload: body('Bonjour'),
  });
  assert.equal(lan.statusCode, 401, 'un téléphone non autorisé n’accède pas à la conversation');
  for (const payload of [
    { messages: [] },
    body(' '),
    body('x'.repeat(1001)),
    { messages: [{ role: 'assistant', text: 'seul' }] },
  ]) {
    const invalid = await server.inject({
      method: 'POST',
      url: '/api/text',
      headers: local,
      payload,
    });
    assert.equal(invalid.statusCode, 400, JSON.stringify(payload).slice(0, 40));
  }
  const ok = await server.inject({
    method: 'POST',
    url: '/api/text',
    headers: local,
    payload: body('Bonjour'),
  });
  assert.equal(ok.statusCode, 200);
  assert.equal(ok.json().text, 'Bonjour !');
  assert.deepEqual((await server.inject({ url: '/api/text/status', headers: local })).json(), {
    ready: true,
    reason: null,
  });
});

test('API : OpenAI bloqué par l’administration → 409 ; sans clé → 503', async (t) => {
  const server = await app(t, async () => answer('jamais'));
  const login = await server.inject({
    method: 'POST',
    url: '/api/login',
    headers: local,
    payload: { password: 'mot-de-passe-texte' },
  });
  assert.equal(login.statusCode, 200);
  const cookies = Object.fromEntries(login.cookies.map((c) => [c.name, c.value]));
  const block = await server.inject({
    method: 'POST',
    url: '/api/admin/openai',
    headers: local,
    cookies,
    payload: { blocked: true },
  });
  assert.equal(block.statusCode, 200);
  const blocked = await server.inject({
    method: 'POST',
    url: '/api/text',
    headers: local,
    payload: body('Bonjour'),
  });
  assert.equal(blocked.statusCode, 409);
  assert.match(blocked.json().error, /mode privé/);
  const noKey = await app(t, async () => answer('jamais'), null);
  const missing = await noKey.inject({
    method: 'POST',
    url: '/api/text',
    headers: local,
    payload: body('Bonjour'),
  });
  assert.equal(missing.statusCode, 503);
});

test('API sur un vrai réseau : la réponse attendue n’est pas annulée en cours de route', async (t) => {
  const aborted: boolean[] = [];
  const server = await app(t, async (_request, signal) => {
    await new Promise((resolve) => setTimeout(resolve, 80));
    aborted.push(signal.aborted);
    return answer('Toujours là.');
  });
  await server.listen({ port: 0, host: '127.0.0.1' });
  const { port } = server.server.address() as { port: number };
  const response = await fetch(`http://127.0.0.1:${port}/api/text`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', origin: 'http://localhost', host: 'localhost' },
    body: JSON.stringify(body('Bonjour')),
  });
  assert.equal(response.status, 200);
  assert.equal(((await response.json()) as { text: string }).text, 'Toujours là.');
  assert.deepEqual(aborted, [false]);
});
