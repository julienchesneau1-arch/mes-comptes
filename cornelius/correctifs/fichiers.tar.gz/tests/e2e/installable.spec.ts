import { expect, test } from '@playwright/test';

// Tablette ou téléphone : l’icône de l’écran d’accueil ouvre Cornelius en plein écran.
test('le miroir s’installe en plein écran : manifeste, icônes et balises iPad', async ({
  page,
}) => {
  await page.goto('/');
  await expect(page.locator('link[rel="manifest"]')).toHaveAttribute(
    'href',
    '/manifest-miroir.webmanifest',
  );
  await expect(page.locator('meta[name="apple-mobile-web-app-capable"]')).toHaveAttribute(
    'content',
    'yes',
  );
  const response = await page.request.get('/manifest-miroir.webmanifest');
  expect(response.status()).toBe(200);
  const manifest = (await response.json()) as {
    start_url: string;
    display: string;
    icons: { src: string; sizes: string; purpose: string }[];
  };
  expect(manifest.start_url).toBe('/');
  expect(manifest.display).toBe('fullscreen');
  expect(manifest.icons.map((icon) => icon.purpose)).toEqual(['any', 'any', 'maskable']);
  for (const src of [...manifest.icons.map((icon) => icon.src), '/apple-touch-icon.png']) {
    const icon = await page.request.get(src);
    expect(icon.status(), src).toBe(200);
    expect(icon.headers()['content-type']).toContain('image/png');
  }
  // La politique de sécurité du contenu laisse le navigateur lire le manifeste (même origine).
  expect(response.headers()['content-security-policy'] ?? '').not.toContain('manifest-src');
});
