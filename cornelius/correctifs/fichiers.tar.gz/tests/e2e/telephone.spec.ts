import { expect, test, type Page, type Route } from '@playwright/test';
import type { TextReply, TextTurn } from '../../shared/text-chat';
import { screenshots } from './env';

// Téléphone de la maison : conversation écrite au nom du foyer, sans prendre la place du miroir.
test.use({ viewport: { width: 390, height: 844 }, hasTouch: true });

const ready = (page: Page) =>
  page.route('**/api/text/status', (route) =>
    route.fulfill({ json: { ready: true, reason: null } }),
  );

const card = {
  schemaVersion: 1,
  cardType: 'module',
  addonId: 'foyer',
  instanceRef: null,
  title: 'Foyer',
  primaryValue: 'Curry de poulet',
  subtitle: 'Ce soir',
  description: null,
  items: [{ label: 'Demain midi', value: 'Salade niçoise' }],
  sources: [],
  snapshotId: 'foyer-1',
  stale: false,
};

test('installable à part, sans ouvrir de miroir, au doigt et lisible', async ({ page }) => {
  const sockets: string[] = [];
  page.on('websocket', (socket) => sockets.push(socket.url()));
  await ready(page);
  await page.goto('/telephone');
  await expect(page.getByRole('heading', { name: 'Cornelius' })).toBeVisible();
  await expect(page).toHaveTitle('Écrire à Cornelius');
  await expect(page.locator('link[rel="manifest"]')).toHaveAttribute(
    'href',
    '/manifest-telephone.webmanifest',
  );
  const manifest = (await (await page.request.get('/manifest-telephone.webmanifest')).json()) as {
    id: string;
    start_url: string;
    scope: string;
    display: string;
  };
  expect(manifest).toMatchObject({
    id: '/telephone',
    start_url: '/telephone',
    scope: '/telephone',
    display: 'standalone',
  });
  // Le miroir actif (un seul à la fois) n’est jamais remplacé par la page téléphone.
  expect(sockets.filter((url) => url.includes('/events'))).toEqual([]);

  const input = page.getByLabel('Votre message');
  const send = page.getByRole('button', { name: 'Envoyer' });
  await expect(send).toBeDisabled();
  await input.fill('Bonjour');
  await expect(send).toBeEnabled();
  for (const target of [send, page.getByRole('button', { name: 'Effacer' }), input]) {
    const box = await target.boundingBox();
    expect(box?.height ?? 0).toBeGreaterThanOrEqual(44);
  }
  // 16 px au moins : iOS ne zoome pas sur le champ.
  expect(
    await input.evaluate((node) => parseFloat(getComputedStyle(node).fontSize)),
  ).toBeGreaterThanOrEqual(16);
  const overflow = await page.evaluate(
    () => document.documentElement.scrollWidth - document.documentElement.clientWidth,
  );
  expect(overflow).toBeLessThanOrEqual(0);
});

test('réponse, puis panne : échec affiché, ce qui a été lancé listé, jamais « c’est fait »', async ({
  page,
}) => {
  await ready(page);
  const sent: TextTurn[][] = [];
  const replies: ((route: Route) => Promise<void>)[] = [
    async (route) => {
      // Lenteur volontaire : l’état « en cours » doit être visible.
      await new Promise((resolve) => setTimeout(resolve, 400));
      const reply: TextReply = {
        status: 'succeeded',
        text: 'Ce soir : curry de poulet.',
        cards: [card as TextReply['cards'][number]],
        actions: [{ tool: 'foyer__read', status: 'succeeded', summary: 'Repas lus.' }],
      };
      await route.fulfill({ json: reply });
    },
    (route) =>
      route.fulfill({
        json: {
          status: 'failed',
          text: 'Cornelius n’a pas pu terminer sa réponse. Ce qui a déjà été lancé est indiqué ci-dessous.',
          cards: [],
          actions: [
            {
              tool: 'home_assistant__control',
              status: 'unknown',
              summary: 'Lumière du salon : commande envoyée, état non confirmé.',
            },
          ],
        } satisfies TextReply,
      }),
    (route) => route.fulfill({ status: 502, json: { error: 'Cornelius n’a pas pu répondre.' } }),
  ];
  await page.route('**/api/text', async (route) => {
    sent.push((route.request().postDataJSON() as { messages: TextTurn[] }).messages);
    await replies[sent.length - 1]!(route);
  });
  await page.goto('/telephone');
  const input = page.getByLabel('Votre message');
  const send = page.getByRole('button', { name: /Envoyer|Envoi/ });

  await input.fill('Qu’est-ce qu’on mange ce soir ?');
  await input.press('Enter');
  await expect(page.getByRole('status')).toHaveText('Cornelius réfléchit…');
  await expect(send).toBeDisabled();
  await expect(page.getByText('Ce soir : curry de poulet.')).toBeVisible();
  await expect(page.getByRole('region', { name: 'Foyer' })).toContainText('Curry de poulet');
  await expect(page.getByRole('region', { name: 'Foyer' })).toContainText('Salade niçoise');
  await expect(input).toHaveValue('');

  await input.fill('Allume le salon');
  await send.click();
  const failure = page.getByRole('alert');
  await expect(failure).toContainText('n’a pas pu terminer');
  await expect(failure.getByRole('list', { name: 'Ce qui a été lancé' })).toContainText(
    'non confirmé · Lumière du salon : commande envoyée, état non confirmé.',
  );
  await expect(failure).not.toContainText(/c’est fait|allumée/);
  // La question revient dans le champ, à renvoyer en connaissance de cause.
  await expect(input).toHaveValue('Allume le salon');

  await send.click();
  await expect(page.getByRole('alert').last()).toHaveText('Cornelius n’a pas pu répondre.');

  // Seuls les échanges réussis servent de contexte : jamais une réponse en échec.
  expect(sent[0]).toEqual([{ role: 'user', text: 'Qu’est-ce qu’on mange ce soir ?' }]);
  expect(sent[1]).toEqual([
    { role: 'user', text: 'Qu’est-ce qu’on mange ce soir ?' },
    { role: 'assistant', text: 'Ce soir : curry de poulet.' },
    { role: 'user', text: 'Allume le salon' },
  ]);
  expect(sent[2]).toEqual(sent[1]);

  await page.screenshot({ path: `${screenshots}/telephone-conversation.png` });
  await page.getByRole('button', { name: 'Effacer' }).click();
  await expect(page.getByText('Ce soir : curry de poulet.')).toHaveCount(0);
});

test('mode privé : refus dit clairement, rien ne s’envoie', async ({ page }) => {
  await page.route('**/api/text/status', (route) =>
    route.fulfill({ json: { ready: false, reason: 'blocked' } }),
  );
  let posted = false;
  await page.route('**/api/text', (route) => {
    posted = true;
    return route.abort();
  });
  await page.goto('/telephone');
  await expect(page.getByRole('alert')).toContainText('Mode privé');
  await expect(page.getByLabel('Votre message')).toBeDisabled();
  await expect(page.getByRole('button', { name: 'Envoyer' })).toBeDisabled();
  expect(posted).toBe(false);
});

test('serveur réel sans clé OpenAI : indisponible, dit comme tel', async ({ page }) => {
  await page.goto('/telephone');
  await expect(page.getByRole('alert')).toContainText('Clé OpenAI absente');
  await expect(page.getByLabel('Votre message')).toBeDisabled();
});

test('serveur injoignable : dit comme tel, puis rétabli', async ({ page }) => {
  let up = false;
  await page.route('**/api/text/status', (route) =>
    up ? route.fulfill({ json: { ready: true, reason: null } }) : route.abort('connectionrefused'),
  );
  await page.goto('/telephone');
  await expect(page.getByRole('alert')).toContainText('injoignable');
  up = true;
  await page.getByRole('button', { name: 'Réessayer' }).click();
  await expect(page.getByRole('alert')).toHaveCount(0);
  await expect(page.getByLabel('Votre message')).toBeEnabled();
});
