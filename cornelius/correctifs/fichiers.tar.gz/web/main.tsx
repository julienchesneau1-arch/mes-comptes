import { reportDiagnostic } from './diagnostics';
import React from 'react';
import ReactDOM from 'react-dom/client';
import { App } from './App';
import './styles.css';

window.addEventListener('error', (event) =>
  reportDiagnostic(
    'error',
    'erreur JavaScript non interceptée',
    event.error ?? new Error(event.message),
  ),
);
window.addEventListener('unhandledrejection', (event) =>
  reportDiagnostic('error', 'promesse rejetée non interceptée', event.reason),
);

// Page téléphone : son propre manifeste, pour que l’icône installée rouvre /telephone.
if (/^\/telephone\/?$/.test(location.pathname)) {
  document
    .querySelector('link[rel="manifest"]')
    ?.setAttribute('href', '/manifest-telephone.webmanifest');
  document
    .querySelector('meta[name="apple-mobile-web-app-title"]')
    ?.setAttribute('content', 'Écrire');
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
