import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type FormEvent,
  type KeyboardEvent,
} from 'react';
import { api, errorMessage, RequestTimeoutError } from '../api';
import type { ModuleCard } from '../../shared/addons';
import {
  TEXT_MAX_LENGTH,
  TEXT_MAX_TURNS,
  type TextAction,
  type TextStatus,
  type TextTurn,
} from '../../shared/text-chat';

export interface ChatEntry {
  id: number;
  role: 'user' | 'assistant';
  text: string;
  /** Réponse en échec : affichée, jamais renvoyée au modèle comme contexte. */
  failed?: boolean;
  cards?: ModuleCard[];
  actions?: TextAction[];
}

/** Contexte envoyé : les échanges réussis les plus récents, puis la nouvelle question. */
export function history(entries: ChatEntry[], text: string): TextTurn[] {
  const turns: TextTurn[] = [];
  for (let i = 0; i < entries.length - 1; i++) {
    const asked = entries[i];
    const answered = entries[i + 1];
    if (asked?.role === 'user' && answered?.role === 'assistant' && !answered.failed)
      turns.push(
        { role: 'user', text: asked.text },
        { role: 'assistant', text: answered.text.slice(0, TEXT_MAX_LENGTH) },
      );
  }
  return [...turns.slice(-(TEXT_MAX_TURNS - 2)), { role: 'user', text }];
}

const UNAVAILABLE: Record<NonNullable<TextStatus['reason']>, string> = {
  blocked:
    'Mode privé : Cornelius ne répond pas par écrit (OpenAI est bloqué dans l’administration).',
  no_key: 'Clé OpenAI absente : à ajouter dans l’administration, rubrique Mise en route.',
};
const UNREACHABLE =
  'Cornelius est injoignable. Vérifiez la connexion : réseau de la maison ou Tailscale.';
const TIMEOUT =
  'Pas de réponse à temps. Une commande a peut-être été lancée : vérifiez avant de redemander.';
const ACTION_STATUS: Record<string, string> = {
  succeeded: 'fait',
  empty: 'rien trouvé',
  stale: 'ancien relevé',
  failed: 'échec',
  pending_confirmation: 'en attente de confirmation',
  unknown: 'non confirmé',
  cancelled: 'annulé',
};

/**
 * Conversation écrite au nom du foyer (téléphone, tablette). Rien n’est gardé dans le
 * navigateur : la conversation disparaît en fermant la page.
 */
export function Chat() {
  const [entries, setEntries] = useState<ChatEntry[]>([]);
  const [draft, setDraft] = useState('');
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<TextStatus | null>(null);
  const [statusError, setStatusError] = useState(false);
  const nextId = useRef(1);
  const pending = useRef<AbortController | null>(null);
  const end = useRef<HTMLDivElement>(null);

  const checkStatus = useCallback(async () => {
    try {
      setStatus(await api.textStatus());
      setStatusError(false);
    } catch {
      setStatusError(true);
    }
  }, []);
  useEffect(() => {
    document.title = 'Écrire à Cornelius';
    void checkStatus();
    const visible = () => {
      if (document.visibilityState === 'visible') void checkStatus();
    };
    document.addEventListener('visibilitychange', visible);
    window.addEventListener('online', visible);
    return () => {
      document.removeEventListener('visibilitychange', visible);
      window.removeEventListener('online', visible);
      pending.current?.abort();
    };
  }, [checkStatus]);
  useEffect(() => {
    end.current?.scrollIntoView?.({ block: 'end' });
  }, [entries, busy]);

  const ready = status?.ready === true && !statusError;
  const text = draft.trim();

  async function send(event?: FormEvent) {
    event?.preventDefault();
    if (!ready || busy || !text) return;
    const turns = history(entries, text);
    const asked: ChatEntry = { id: nextId.current++, role: 'user', text };
    setEntries((current) => [...current, asked]);
    setDraft('');
    setBusy(true);
    const controller = new AbortController();
    pending.current = controller;
    let answer: ChatEntry;
    try {
      const reply = await api.text(turns, controller.signal);
      answer = {
        id: nextId.current++,
        role: 'assistant',
        text: reply.text,
        failed: reply.status !== 'succeeded',
        cards: reply.cards,
        actions: reply.actions,
      };
    } catch (failure) {
      if (controller.signal.aborted) return;
      answer = {
        id: nextId.current++,
        role: 'assistant',
        text: failure instanceof RequestTimeoutError ? TIMEOUT : errorMessage(failure),
        failed: true,
      };
      void checkStatus();
    } finally {
      if (pending.current === controller) pending.current = null;
      setBusy(false);
    }
    setEntries((current) => [...current, answer]);
    // Échec : la question revient dans le champ, à renvoyer en connaissance de cause.
    if (answer.failed) setDraft((current) => current || text);
  }

  function keyDown(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === 'Enter' && !event.shiftKey && !event.nativeEvent.isComposing) {
      event.preventDefault();
      void send();
    }
  }

  const notice = statusError
    ? UNREACHABLE
    : status && !status.ready && status.reason
      ? UNAVAILABLE[status.reason]
      : null;

  return (
    <main className="chat-page">
      <header className="chat-header">
        <span className="chat-orb" aria-hidden="true" />
        <h1>Cornelius</h1>
        <span className="chat-scope">au nom du foyer</span>
        <button
          type="button"
          className="chat-clear"
          onClick={() => {
            pending.current?.abort();
            setEntries([]);
            setBusy(false);
          }}
          disabled={!entries.length && !busy}
        >
          Effacer
        </button>
      </header>
      {notice && (
        <div className="chat-notice" role="alert">
          <p>{notice}</p>
          <button type="button" onClick={() => void checkStatus()}>
            Réessayer
          </button>
        </div>
      )}
      <div className="chat-log" role="log" aria-live="polite" aria-busy={busy}>
        {!entries.length && (
          <p className="chat-empty">
            Demandez le repas de ce soir, les courses, la météo ou les transports. Les souvenirs et
            les comptes personnels restent devant le miroir.
          </p>
        )}
        {entries.map((entry) => (
          <Message key={entry.id} entry={entry} />
        ))}
        {busy && (
          <p className="chat-message chat-assistant chat-pending" role="status">
            Cornelius réfléchit…
          </p>
        )}
        <div ref={end} />
      </div>
      <form className="chat-form" onSubmit={(event) => void send(event)}>
        <label htmlFor="chat-input" className="chat-label">
          Votre message
        </label>
        <textarea
          id="chat-input"
          rows={2}
          maxLength={TEXT_MAX_LENGTH}
          enterKeyHint="send"
          placeholder={ready ? 'Écrire à Cornelius…' : 'Indisponible pour le moment'}
          value={draft}
          onChange={(event) => setDraft(event.target.value)}
          onKeyDown={keyDown}
          disabled={!ready}
        />
        <button type="submit" disabled={!ready || busy || !text}>
          {busy ? 'Envoi…' : 'Envoyer'}
        </button>
      </form>
    </main>
  );
}

function Message({ entry }: { entry: ChatEntry }) {
  if (entry.role === 'user') return <p className="chat-message chat-user">{entry.text}</p>;
  return (
    <div
      className={`chat-message chat-assistant${entry.failed ? ' chat-failed' : ''}`}
      role={entry.failed ? 'alert' : undefined}
    >
      <p>{entry.text}</p>
      {!!entry.actions?.length && (
        <ul className="chat-actions" aria-label="Ce qui a été lancé">
          {entry.actions.map((action, index) => (
            <li key={index}>
              <strong>{ACTION_STATUS[action.status] ?? action.status}</strong> · {action.summary}
            </li>
          ))}
        </ul>
      )}
      {entry.cards?.map((card) => (
        <section className="chat-card" key={card.snapshotId} aria-label={card.title}>
          <h2>
            {card.title}
            {card.stale && <span className="chat-stale"> · ancien relevé</span>}
          </h2>
          {card.primaryValue && <p className="chat-card-value">{card.primaryValue}</p>}
          {card.subtitle && <p>{card.subtitle}</p>}
          {!!card.items.length && (
            <dl>
              {card.items.map((item, index) => (
                <div key={index}>
                  <dt>{item.label}</dt>
                  <dd>{item.value}</dd>
                </div>
              ))}
            </dl>
          )}
        </section>
      ))}
    </div>
  );
}
