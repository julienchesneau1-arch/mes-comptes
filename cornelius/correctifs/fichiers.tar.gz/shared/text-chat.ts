import type { ModuleCard } from './addons.js';

/** Conversation écrite (téléphone, tablette) : au nom du foyer, jamais d’une personne. */
export const TEXT_MAX_TURNS = 12;
export const TEXT_MAX_LENGTH = 1000;

export interface TextTurn {
  role: 'user' | 'assistant';
  text: string;
}

/** Outil réellement exécuté pendant la réponse, montré même si la réponse finale échoue. */
export interface TextAction {
  tool: string;
  status: string;
  summary: string;
}

export interface TextReply {
  status: 'succeeded' | 'failed';
  text: string;
  cards: ModuleCard[];
  actions: TextAction[];
}

export interface TextStatus {
  ready: boolean;
  /** blocked : OpenAI bloqué (mode privé) ; no_key : clé OpenAI absente. */
  reason: 'blocked' | 'no_key' | null;
}
